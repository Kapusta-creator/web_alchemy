from flask import Flask, render_template, redirect
from data import db_session
from data.users import User
from data.login_form import LoginForm
from data.jobs import Jobs
from datetime import datetime as dt

app = Flask(__name__)
app.config['SECRET_KEY'] = "Yandexlyceum_key"


def create_user(surname, name, age, position, speciality, address, email):
    user = User()
    user.surname = surname
    user.name = name
    user.age = age
    user.position = position
    user.speciality = speciality
    user.address = address
    user.email = email
    return user


def create_job(team_leader, job, work_size, collaborators, start_date, is_finished):
    new_job = Jobs()
    new_job.team_leader = team_leader
    new_job.job = job
    new_job.work_size = work_size
    new_job.collaborators = collaborators
    new_job.start_date = start_date
    new_job.is_finished = is_finished
    return new_job


def main():
    # db_session.global_init("db/mars_explorer.db")
    # job = create_job(3, "Development of a managment system", 25, "5", dt.now, False)
    # session = db_session.create_session()
    # for user in session.query(User).filter((User.id > 1) | (User.email.like("%ya@ya.ru%"))):
    #    print(user)
    # user = session.query(User).first()
    # print(user.name)
    # session.query(User).filter(User.name == "Дима").delete()
    # user = session.query(User).filter(User.id == 1).first()
    # news = News(title="Личная новость!", content="скоро др!", is_private=True)
    # user.news.append(news)
    # session.add(job)
    # session.commit()
    app.run()


@app.route("/")
def jobs():
    db_session.global_init("db/mars_explorer.db")
    session = db_session.create_session()
    job = session.query(Jobs).filter()
    return render_template("table.html", jobs=job, session=session, User=User)


if __name__ == '__main__':
    main()
